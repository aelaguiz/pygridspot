from basic import *
from v1 import *
from instancelist import *

## This unit test isn't really possible to run automatically since it requires a
#target server, so if you really want to run it you need to uncomment and prep
#the test with your credentials
#from bootstrap import *
